# Jones Logistics 2026 Trucking Update

Interactive presentation for sharing market intelligence and strategic outlook.

## Deploy to GitHub Pages (Free)

### Step-by-Step Instructions

1. **Create a GitHub account** (if you don't have one): [github.com/signup](https://github.com/signup)

2. **Create a new repository**:
   - Go to [github.com/new](https://github.com/new)
   - Name it: `jones-trucking-2026` (or anything you want)
   - Select **Public**
   - Click **Create repository**

3. **Upload the files**:
   - On your new repo page, click **"uploading an existing file"**
   - Drag `index.html` into the upload area
   - Click **Commit changes**

4. **Enable GitHub Pages**:
   - Go to **Settings** (tab at top)
   - Scroll to **Pages** (left sidebar)
   - Under "Source", select **main** branch
   - Click **Save**

5. **Get your live URL** (appears in ~1 minute):
   ```
   https://YOUR-USERNAME.github.io/jones-trucking-2026/
   ```

## Other Free Hosting Options

| Service | URL Format | Notes |
|---------|------------|-------|
| **GitHub Pages** | `username.github.io/repo` | Best for tech users |
| **Netlify** | `sitename.netlify.app` | Drag & drop |
| **Vercel** | `sitename.vercel.app` | GitHub integration |
| **Cloudflare Pages** | `sitename.pages.dev` | Fast CDN |
| **Render** | `sitename.onrender.com` | Simple setup |

## Features

- ✅ Auto-play slideshow (5 second intervals)
- ✅ Keyboard navigation (←→ arrows, spacebar)
- ✅ Touch/swipe support for mobile
- ✅ Progress indicator
- ✅ Responsive design
- ✅ Jones Logistics branding

---

**Jones Logistics** | 607 Corinne Street, Hattiesburg, MS 39401 | 800-956-1151
